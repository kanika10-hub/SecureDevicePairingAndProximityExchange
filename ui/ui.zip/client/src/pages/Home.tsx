import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowDownRight,
  Check,
  ChevronDown,
  CircleDot,
  KeyRound,
  Laptop,
  LockKeyhole,
  RadioTower,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  UserRoundX,
  Wifi,
  X,
  Zap,
} from "lucide-react";

type Scenario = "pair" | "reconnect" | "stranger";
type Phase = "ready" | "negotiating" | "success" | "rejected";

type Banner = {
  tone: "success" | "danger";
  title: string;
  detail: string;
  icon: typeof Check;
};

const scenarioMeta: Record<Scenario, { label: string; caption: string; action: string }> = {
  pair: { label: "Pair new device", caption: "First-time secure handshake", action: "Start pairing" },
  reconnect: { label: "Reconnect previous", caption: "Resume a trusted session", action: "Reconnect" },
  stranger: { label: "Block unknown", caption: "Reject an unrecognized key", action: "Block device" },
};

const baseKeys = [
  { label: "session_id", value: "0x7F91...A82C", tone: "cyan" },
  { label: "cipher_suite", value: "0x1301 / AES-GCM", tone: "violet" },
  { label: "trust_level", value: "0xTRUSTED", tone: "lime" },
  { label: "last_seen", value: "0x2m 14s ago", tone: "amber" },
];

const strangerKeys = [
  { label: "session_id", value: "0xBAD0...91FF", tone: "red" },
  { label: "cipher_suite", value: "0x0000 / UNKNOWN", tone: "red" },
  { label: "trust_level", value: "0xUNVERIFIED", tone: "amber" },
  { label: "last_seen", value: "0xnever", tone: "muted" },
];

function KeyRows({ stranger = false }: { stranger?: boolean }) {
  const rows = stranger ? strangerKeys : baseKeys;
  return (
    <div className="key-table" aria-label="Session key values">
      {rows.map((row) => (
        <div className="key-row" key={row.label}>
          <span className="key-label">{row.label}</span>
          <span className={`key-value ${row.tone}`}>{row.value}</span>
        </div>
      ))}
    </div>
  );
}

function EndpointCard({
  side,
  stranger,
  phase,
}: {
  side: "left" | "right";
  stranger?: boolean;
  phase: Phase;
}) {
  const isLeft = side === "left";
  const isNegotiating = phase === "negotiating";
  const isRejected = stranger && phase === "rejected";
  return (
    <article className={`endpoint-card ${side} ${stranger ? "stranger-card" : ""} ${isRejected ? "is-rejected" : ""}`}>
      <div className="card-topline">
        <div className={`device-orb ${isLeft ? "orb-blue" : stranger ? "orb-red" : "orb-lime"}`}>
          {isLeft ? <Laptop size={20} strokeWidth={1.7} /> : stranger ? <UserRoundX size={20} strokeWidth={1.7} /> : <Smartphone size={20} strokeWidth={1.7} />}
        </div>
        <div className="device-meta">
          <span className="eyebrow">{isLeft ? "ORIGIN DEVICE" : stranger ? "UNRECOGNIZED PEER" : "TARGET DEVICE"}</span>
          <h2>{isLeft ? "MacBook Pro 14\"" : stranger ? "Unknown Android" : "Pixel 9 Pro"}</h2>
        </div>
        <span className={`presence ${isRejected ? "offline" : isNegotiating ? "syncing" : "online"}`}>
          <span className="presence-dot" />
          {isRejected ? "blocked" : isNegotiating ? "syncing" : "online"}
        </span>
      </div>
      <div className="device-location">
        <Wifi size={13} />
        <span>{isLeft ? "This device" : stranger ? "192.168.1.44 · new" : "192.168.1.18 · familiar"}</span>
      </div>
      <div className="card-divider" />
      <KeyRows stranger={stranger} />
      <div className="fingerprint-row">
        <span className="fingerprint-label">fingerprint</span>
        <span className={`fingerprint ${stranger ? "red" : "cyan"}`}>
          {stranger ? "b3:10:ee:42:9d:08" : isLeft ? "7a:91:cc:4f:10:ae" : "7a:91:cc:4f:10:ae"}
        </span>
        <button className="icon-button" aria-label="Copy fingerprint" onClick={() => navigator.clipboard?.writeText(stranger ? "b3:10:ee:42:9d:08" : "7a:91:cc:4f:10:ae")}>
          <ArrowDownRight size={14} />
        </button>
      </div>
    </article>
  );
}

function Wire({ phase, stranger }: { phase: Phase; stranger: boolean }) {
  const matched = phase === "success" && !stranger;
  const rejected = phase === "rejected";
  return (
    <div className={`wire-zone ${matched ? "matched" : ""} ${rejected ? "rejected" : ""}`} aria-label="Encrypted connection status">
      <div className="wire-label top">network</div>
      <div className="wire-core">
        <div className="wire-glow" />
        <div className="wire-line" />
        <div className="wire-node node-top"><span /></div>
        <div className="wire-node node-bottom"><span /></div>
        {matched && <div className="match-mark"><Check size={13} /></div>}
        {rejected && <div className="match-mark reject-mark"><X size={13} /></div>}
      </div>
      <div className="wire-label bottom">encrypted</div>
      <span className="wire-status">{matched ? "key match" : rejected ? "access denied" : phase === "negotiating" ? "negotiating" : "standby"}</span>
    </div>
  );
}

export default function Home() {
  const [scenario, setScenario] = useState<Scenario>("pair");
  const [phase, setPhase] = useState<Phase>("success");
  const [banner, setBanner] = useState<Banner>({
    tone: "success",
    title: "Pairing complete",
    detail: "Fingerprint 7a:91:cc:4f:10:ae is now trusted",
    icon: Check,
  });
  const [isOpen, setIsOpen] = useState(false);

  const stranger = scenario === "stranger";
  const meta = scenarioMeta[scenario];
  const statusLabel = useMemo(() => {
    if (phase === "negotiating") return "session negotiating";
    if (phase === "rejected") return "access denied";
    return scenario === "reconnect" ? "session reconnected" : "session secure";
  }, [phase, scenario]);

  useEffect(() => {
    if (phase !== "negotiating") return;
    const timer = window.setTimeout(() => {
      if (scenario === "stranger") {
        setPhase("rejected");
        setBanner({ tone: "danger", title: "Stranger blocked", detail: "Unknown fingerprint rejected before key exchange", icon: UserRoundX });
      } else {
        setPhase("success");
        setBanner({
          tone: "success",
          title: scenario === "reconnect" ? "Session reconnected" : "Pairing complete",
          detail: scenario === "reconnect" ? "Trusted session resumed · key match confirmed" : "Fingerprint 7a:91:cc:4f:10:ae is now trusted",
          icon: scenario === "reconnect" ? RefreshCw : Check,
        });
      }
    }, 1050);
    return () => window.clearTimeout(timer);
  }, [phase, scenario]);

  const runScenario = (nextScenario = scenario) => {
    setScenario(nextScenario);
    setPhase("negotiating");
    setBanner({ tone: "success", title: "Comparing fingerprints", detail: "Both devices are deriving a shared session key…", icon: KeyRound });
  };

  return (
    <main className="console-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark"><ShieldCheck size={18} strokeWidth={1.8} /></div>
          <div>
            <div className="brand-name">CIPHER<span>/</span>LINK</div>
            <div className="brand-caption">secure session console</div>
          </div>
        </div>
        <div className="topbar-right">
          <div className="live-indicator"><span className="live-dot" /> relay online</div>
          <button className="avatar-button" aria-label="Open account menu" onClick={() => setIsOpen((value) => !value)}>AR</button>
          {isOpen && <div className="account-popover"><span>operator</span><strong>Alex Rivera</strong><small>local-only mode</small></div>}
        </div>
      </header>

      <section className="hero-intro">
        <div>
          <div className="section-kicker"><span className="kicker-line" /> session / 0042</div>
          <h1>Pair with confidence<span>.</span></h1>
          <p>Compare device fingerprints before a secure channel opens.</p>
        </div>
        <div className={`hero-status ${phase === "rejected" ? "status-danger" : phase === "negotiating" ? "status-syncing" : ""}`}>
          <CircleDot size={15} />
          <div><span>current state</span><strong>{statusLabel}</strong></div>
          <ChevronDown size={15} />
        </div>
      </section>

      <section className="scenario-bar" aria-label="Pairing scenarios">
        <div className="scenario-tabs">
          {(Object.keys(scenarioMeta) as Scenario[]).map((item) => (
            <button key={item} className={`scenario-tab ${scenario === item ? "active" : ""}`} onClick={() => { setScenario(item); setPhase(item === "stranger" ? "rejected" : "success"); setBanner(item === "stranger" ? { tone: "danger", title: "Stranger blocked", detail: "Unknown fingerprint rejected before key exchange", icon: UserRoundX } : { tone: "success", title: item === "reconnect" ? "Session reconnected" : "Pairing complete", detail: item === "reconnect" ? "Trusted session resumed · key match confirmed" : "Fingerprint 7a:91:cc:4f:10:ae is now trusted", icon: item === "reconnect" ? RefreshCw : Check }); }}>
              {item === "pair" ? <Zap size={14} /> : item === "reconnect" ? <RefreshCw size={14} /> : <UserRoundX size={14} />}
              <span>{scenarioMeta[item].label}</span>
            </button>
          ))}
        </div>
        <button className={`run-button ${stranger ? "danger-button" : ""}`} onClick={() => runScenario()}>
          {stranger ? <UserRoundX size={15} /> : scenario === "reconnect" ? <RefreshCw size={15} /> : <RadioTower size={15} />}
          {meta.action}
        </button>
      </section>

      <section className="connection-grid">
        <EndpointCard side="left" phase={phase} />
        <Wire phase={phase} stranger={stranger} />
        <EndpointCard side="right" phase={phase} stranger={stranger} />
      </section>

      <section className="lower-grid">
        <div className="event-card">
          <div className="panel-heading"><span><Activity size={15} /> exchange log</span><span className="live-tag">live</span></div>
          <div className="event-list">
            <div className="event-row"><span className="event-time">00:08:29</span><span className="event-dot cyan-dot" /><span>relay heartbeat received</span><b>ok</b></div>
            <div className="event-row"><span className="event-time">00:08:30</span><span className={`event-dot ${stranger ? "red-dot" : "lime-dot"}`} /><span>{stranger ? "unknown peer fingerprint flagged" : "trusted peer fingerprint cached"}</span><b className={stranger ? "danger-text" : ""}>{stranger ? "warn" : "ok"}</b></div>
          </div>
        </div>
        <div className="metric-card">
          <div className="panel-heading"><span><LockKeyhole size={15} /> channel health</span><span className="tiny-label">AES-256-GCM</span></div>
          <div className="metric-main"><strong>99.98<span>%</span></strong><span>integrity score</span></div>
          <div className="health-bar"><span /></div>
          <div className="metric-footer"><span>latency <b>18ms</b></span><span>entropy <b>high</b></span></div>
        </div>
      </section>

      <div className={`floating-banner ${banner.tone} ${phase === "negotiating" ? "is-negotiating" : ""}`} role="status">
        <div className="banner-icon"> <banner.icon size={17} /> </div>
        <div className="banner-copy"><strong>{banner.title}</strong><span>{banner.detail}</span></div>
        <span className="banner-mark">{phase === "negotiating" ? "…" : banner.tone === "success" ? "verified" : "stopped"}</span>
      </div>
    </main>
  );
}

